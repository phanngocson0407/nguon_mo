<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>The Best Hotel, free css template</title>
<meta name="keywords" content="free css templates, The Best Hotel, HTML CSS" />
<meta name="description" content="The Best Hotel - Free CSS Template, Free HTML CSS Layout" />
<link href="templatemo_style.css?v4" rel="stylesheet" type="text/css" />
</head>
<body>	
    <h1>Họ và tên: Phan Ngọc Sơn MSSV: DH51904385 Lớp: D19_TH04</h1>
        <?php 
            include 'subpages/menu.php'; 
            include 'subpages/content.php';
            include 'subpages/bottom.php';
            include 'subpages/footer.php';
        ?>
</body>
</html>