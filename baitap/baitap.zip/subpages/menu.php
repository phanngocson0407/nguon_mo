<div id="templatemo_header">
        	<div id="templatemo_logo">
            	<span class="orange">THE</span><span class="white">BEST</span><span class="orange">HOTEL</span>
            </div>
            <div id="templatemo_menu">
            	<ul>
                	<li><a href="#">Home</a></li>
                    <li><a href="#">Booking</a></li>
                    <li><a href="#">Facilities</a></li>
                    <li><a href="#">Company</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="subpages/login.php">Log in</a></li>
                    <li><a href="subpages/register.php">Register</a></li>

				</ul>
            </div>
            
        </div>