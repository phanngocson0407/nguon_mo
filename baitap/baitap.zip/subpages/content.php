<div class="templatemo_container">
    <div id="templatemo_content_bg">
        	<div id="templaetmo_content">
            
            	<div id="templatemo_content_left">
                	<div class="templatemo_section">
                    	<div class="templatemo_section_bottom">
    	                	<div class="templatemo_section_top">
                            <div class="templatemo_section_title">Hotel Rooms</div>
                                <ul>
                                    <li><a href="#">Aenean tristique rhoncus </a></li> 
                                    <li><a>Integer condimentum pharetra</a></li>
                                    <li><a>Aliquam eget magna a quam</a></li>
                                    <li><a>Sed sapien elit, consectetur non</a></li>
                                </ul>
	
	                        </div>
                        </div>
                    </div>
                    
                    <div class="templatemo_section">
                    	<div class="templatemo_section_bottom">
    	                	<div class="templatemo_section_top">
                            	<div class="templatemo_section_title">Favorite Links</div>
                                <ul>
                                    <li><a href="http://www.flashmo.com" target="_parent">Free Flash Template</a></li> 
                                    <li><a href="http://www.templatemo.com" target="_parent">Free CSS Template</a></li>
                                    <li><a href="http://www.webdesignmo.com" target="_parent">Web Design Articles</a></li>
                                    <li><a href="http://www.photovaco.com" target="_parent">Royalty Free Photos</a></li>
                                    <li><a href="http://www.flashmo.com" target="_parent">Flash Templates</a></li> 
                                    <li><a href="http://www.templatemo.com" target="_parent">CSS Templates</a></li>
                                </ul>
	
	                        </div>
                        </div>
                    </div>
                    
                    <div class="templatemo_section">
                    	<div class="templatemo_section_bottom">
    	                	<div class="templatemo_section_top">
                            	<div class="templatemo_section_title">Contact Info.</div>
                            	<ul>
                                    <li>Tel: 010-100-1010</li>
                                    <li>Fax: 020-200-2020</li>
                                    <li>E-mail: info@templatemo.com</li>
                                </ul>
	                        </div>
                        </div>
                    </div>
                </div><!-- End Of content left-->
                
                <div id="templatemo_content_right">
                	<div class="templatemo_post_area">
						<div class="templatemo_post_title">
                        	Welcome To Our Hotel
    	                </div>
                        <div class="templatemo_post_text">
                        	<p><img src="images/templatemo_thumb_1.jpg" alt="Hotel" border="1" /> This  free CSS template is provided by <a title="css templates" href="http://www.templatemo.com" target="_parent">TemplateMo.com</a> website. Feel free to download, modify and apply this CSS layout for your personal or commercial websites.</p>
                       	    <p>Aliquam tristique lacus in sapien. Suspendisse potenti. Ut sed pede. Nullam vitae tellus. Sed ultrices. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
                            <p>Suspendisse in quam sed sapien vehicula lacinia eget sed metus. Praesent faucibus lorem ac est malesuada sed auctor orci dictum.</p>
                            
                            <div class="templatemo_post_info">
                            	Posted By: Admin | Category: <a href="#">About</a> | Date: 18 April 2024
                            </div>
                        </div>
					</div>
                    
                    <div class="templatemo_post_area">
                    	<div class="templatemo_post_title">
                        	Customer Services</div>
                        
                        <div class="templatemo_post_text">
                        	<p><img src="images/templatemo_thumb_2.jpg" alt="Hotel" border="1" />Integer metus eros, pellentesque nec, pharetra eu, interdum et, nibh. Cras nulla nisi, vestibulum vitae, convallis non, dapibus vitae, ipsum. Mauris tincidunt neque vitae velit. Integer sagittis. Vivamus accumsan massa vitae justo mattis pretium. Sed bibendum lorem at nisi.</p>
                          <p>In sit amet lacus in tellus aliquam fringilla. Quisque euismod. Cras a velit in metus dapibus tempor. Suspendisse diam dui, porta nec, suscipit ac, commodo a, sem. Maecenas justo tellus, mattis eget, ullamcorper et, mollis sit amet, odio.</p>
                            <div class="templatemo_post_info">
                            	Posted By: Admin | Category: <a href="#">Portfilo</a> | Date: 14 April 2024
                            </div>
                        </div>
                    </div>
                    
                </div><!-- End Of content right-->
                
				<div class="cleaner"></div>
            </div><!-- End Of content-->
        </div><!-- End Of content bg -->
</div>