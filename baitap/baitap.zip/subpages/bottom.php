<div id="templatemo_bottom_panel">
    	<div class="templatemo_container">
        
        	<div class="templatemo_bottom_panel_section">
            
            	<div class="templatemo_bottom_section_left">
                	<h1>Latest Posts</h1>
					<ul>
                    	<li><a href="#">Donec blandit euismod felis</a></li>
                        <li><a href="#">Maecenas quam nunc accu msan</a></li>
                        <li><a href="#">Fringilla vel, dapibus vel, est</a></li>
                        <li><a href="#">Morbi mi neque, porta nec</a></li>
                        <li><a href="#">Maecenas pharetra neque vel</a></li>
					</ul>
                </div>
                
                <div class="templatemo_bottom_section_right">
                	<h1>Validations for XHTML and CSS</h1>
                    <p>Nulla augue tortor, interdum vitae, hendrerit ut, mollis eget, orci. Sed turpis turpis, congue a, hendrerit ut, semper eget, est. Proin ut ligula sagittis quam viverra fermentum.</p>
                    <p>
                    	<a href="http://validator.w3.org/check?uri=referer">
                        	<img src="http://www.w3.org/Icons/valid-xhtml10-blue" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
						</a>

						<a href="http://jigsaw.w3.org/css-validator/check/referer">
							<img style="border:0;width:88px;height:31px" src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Valid CSS!" />
	    				</a>
                    </p>
                </div>
                
                <div class="cleaner"></div>
            </div><!-- End Of bottom panel section -->
    </div><!-- End Of Bottom Panel  -->